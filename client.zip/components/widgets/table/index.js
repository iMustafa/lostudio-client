import TableWidget from './table-widget'
import TableWidgetSettings from './table-widget-settings'
export { TableWidget, TableWidgetSettings }