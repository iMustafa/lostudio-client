import CheckboxWidget from './checkbox-widget'
import CheckboxWidgetSettings from './checkbox-widget-settings'

export {
  CheckboxWidget,
  CheckboxWidgetSettings
}