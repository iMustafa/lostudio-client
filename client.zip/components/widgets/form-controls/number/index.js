import NumberWidget from './number-widget'
import NumberWidgetSettings from './number-widget-settings'

export {
  NumberWidget,
  NumberWidgetSettings
}