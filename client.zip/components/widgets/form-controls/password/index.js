import PasswordWidget from './password-widget'
import PasswordWidgetSettings from './password-widget-settings'

export {
  PasswordWidget,
  PasswordWidgetSettings
}