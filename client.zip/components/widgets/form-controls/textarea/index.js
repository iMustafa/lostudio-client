import TextAreaWidget from './textarea-widget'
import TextAreaWidgetSettings from './textarea-widget-settings'

export {
  TextAreaWidget,
  TextAreaWidgetSettings
}