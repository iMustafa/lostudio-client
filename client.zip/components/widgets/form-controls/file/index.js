import FileWidget from './file-widget'
import FileWidgetSettings from './file-widget-settings'

export {
  FileWidget,
  FileWidgetSettings
}