import ImageWidget from './image-widget'
import ImageWidgetSettings from './image-widget-settings'

export {
  ImageWidget,
  ImageWidgetSettings
}