import ParagraphWidget from './paragraph-widget'
import ParagraphWidgetSettings from './paragraph-widget-settings'

export {
  ParagraphWidget,
  ParagraphWidgetSettings
}