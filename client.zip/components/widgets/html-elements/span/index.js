import SpanWidget from './span-widget'
import SpanWidgetSettings from './span-widget-settings'

export {
  SpanWidget,
  SpanWidgetSettings
}