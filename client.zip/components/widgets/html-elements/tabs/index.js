import TabsWidget from './tabs-widget'
import TabsWidgetSettings from './tabs-widget-settings'

export {
  TabsWidget,
  TabsWidgetSettings
}