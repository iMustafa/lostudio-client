import DivWidget from './div-widget'
import DivWidgetSettings from './div-widget-settings'

export {
  DivWidget,
  DivWidgetSettings
}