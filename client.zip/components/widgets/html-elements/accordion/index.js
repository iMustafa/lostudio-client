import AccordionWidget from './accordion-widget'
import AccordionWidgetSettings from './accordion-widget-settings'

export {
  AccordionWidget,
  AccordionWidgetSettings
}