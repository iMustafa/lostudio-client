import DonutChartWidget from './donut-chart-widget'
import DonutChartWidgetSettings from './donut-chart-widget-settings'
export { DonutChartWidget, DonutChartWidgetSettings }