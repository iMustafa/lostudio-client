import BarChartWidget from './bar-chart-widget'
import BarChartWidgetSettings from './bar-chart-widget-settings'
export { BarChartWidget, BarChartWidgetSettings }