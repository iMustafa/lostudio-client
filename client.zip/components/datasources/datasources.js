export default [
  { name: 'Apache Hive' },
  { name: 'Apache Phoenix' },
  { name: 'Apache Spark' },
  { name: 'Azure SQL' },
  { name: 'Drill' },
  { name: 'Google Big Query', type: 'gbq' },
  { name: 'Impala' },
  { name: 'MongoDB' },
  { name: 'Microsoft SQL Server', type: 'mssql' },
  { name: 'MySQL Enterprise Edition', type: 'mysql' },
  { name: 'Oracle SQL', type: 'oracle' },
  { name: 'Postgre SQL', type: 'postgresql'},
  { name: 'Amazon Redshift', type: 'redshift' }
] 