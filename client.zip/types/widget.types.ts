export default interface Widget {
  _id: string;
  title: string;
  config: any;
  description: any;
}