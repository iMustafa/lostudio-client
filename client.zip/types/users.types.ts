export default interface User {
  email: string;
  password: string;
}