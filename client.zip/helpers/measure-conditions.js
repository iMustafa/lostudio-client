const measureConditionResult = (measureCondition, value) => {
  const { type, minValue, maxValue } = measureCondition
  switch (type) {
    case 'equals':
      return value == minValue ? true : false
    case 'does_not_equal':
      return value != minValue ? true : false
    case 'is_less_than':
      return value < minValue ? true : false
    case 'is_greater_than':
      return value > minValue ? true : false
    case 'is_between':
      return value > minValue && value < maxValue ? true : false
    case 'is_not_between':
      return value < minValue || value > maxValue ? true : false
  }
}

export {
  measureConditionResult
}